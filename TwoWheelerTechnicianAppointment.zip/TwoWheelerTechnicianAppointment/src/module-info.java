module TwoWheelerTechnicianAppointment {
	requires java.sql;
}