package com.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import com.DaoIMPL.CustomerDaoIMPL;
import com.Pojo.Customer;

public class CustomerTest 
{
	CustomerDaoIMPL cd = new CustomerDaoIMPL();
	boolean result;
	List<Customer> li = new ArrayList<Customer>();
	Iterator it;
	int cid;
	Customer obj;
	String cusername, cpassword, ccontact, caddress;
	Scanner sc = new Scanner(System.in);
	
	public void registerCustomer() {
		System.out.println("Enter your cusername ");
		cusername = sc.next();
		System.out.println("Enter your cpassword ");
		cpassword = sc.next();
		System.out.println("Enter your ccontact ");
		ccontact = sc.next();
		System.out.println("Enter your caddress ");
		caddress = sc.next();
		result = cd.AddCustomer(new Customer(cusername,cpassword,ccontact,caddress));
		if(result)
				System.out.println("Registration Done successfully. ");
			else
				System.out.println("Registration Not Done successfully. ");
	}	
	
	public boolean loginCustomer() {
		System.out.println("Enter your cusername ");
		cusername = sc.next();
		System.out.println("Enter your cpassword ");
		cpassword = sc.next();
		li = cd.getCustomerByUsernamePassword(cusername,cpassword);
		if(!li.isEmpty()) {
			obj = li.get(0);
			return true;
		}
		return false;
	}
	
	/*public boolean loginAdmin() {
		System.out.println("Enter admin username ");
		cusername = sc.next();
		System.out.println("Enter admin password ");
		cpassword = sc.next();
		li = cd.getAdminByUsernamePassword(cusername,cpassword);
		if(!li.isEmpty())
			return true;
		return false;
	}*/
				
	public void updateCustomer() {
		System.out.println("Enter Customer id you want to update ");
		cid = sc.nextInt();
		System.out.println("Enter new fname ");
		cusername = sc.next();
		System.out.println("Enter new lname ");
		cpassword = sc.next();
		System.out.println("Enter new email ");
		ccontact = sc.next();
		System.out.println("Enter new mobile ");
		caddress = sc.next();
		Customer c = new Customer(cusername,cpassword,ccontact,caddress);
		c.setCid(cid);
		result = cd.UpdateCustomer(c);
		if(result)
			System.out.println("Customer updated successfully. ");
		else
			System.out.println("Customer not updated successfully. ");
	}
	
	public void updateCustomerByUsername() {
		System.out.println("Enter new cpassword ");
		cpassword = sc.next();
		System.out.println("Enter new ccontact ");
		ccontact = sc.next();
		System.out.println("Enter new caddress ");
		caddress = sc.next();
		Customer c = new Customer(cusername,cpassword,ccontact,caddress);
		c.setCid(cid);
		System.out.println(cusername);
		result = cd.UpdateCustomerByUsername(c);
		if(result)
			System.out.println("Customer updated successfully. ");
		else
			System.out.println("Customer not updated successfully. ");
	}
			
	public void deleteCustomer()
	{
		System.out.println("Enter customer id you want to delete ");
		cid = sc.nextInt();
		result = cd.DeleteCustomer(cid);
		if(result)
			System.out.println("Customer Deleted Successfully. ");
		else
			System.out.println("Customer Not Deleted Successfully. ");
	}
	
	public void deleteCustomerByUsername()
	{
		result = cd.DeleteCustomerByUsername(cusername);
		if(result)
			System.out.println("Customer Deleted Successfully. ");
		else
			System.out.println("Customer Not Deleted Successfully. ");
	}
				
	public void getCustomerById()
	{
		System.out.println("Enter customer id ");
		cid = sc.nextInt();
		li = cd.getCustomerById(cid);
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}	
	
	public Customer getCustomerLoginObject() {
		return obj;
	}
	
	public void getCustomerByUsername()
	{
		li = cd.getCustomerByUsername(cusername);
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}	
				
	public void updateCustomerU(String cusername)
	{
		System.out.println("Enter customer username ");
		cusername = sc.next();
		li = cd.getCustomerByUsername(cusername);
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
							
	public void showAllCustomers()
	{
		li = cd.getAllCustomers();
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}	
}
