package com.Test;

import java.util.Scanner;

public class Test 
{
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int ch;
		System.out.println("1. Customer");
		System.out.println("2. Admin");
		System.out.println("0. Exit");
		System.out.println("Enter your choice: ");
		ch = sc.nextInt();
		do {
			switch(ch) {
			case 1: // customer
				do {
					System.out.println("1. Registration");
					System.out.println("2. Login");
					System.out.println("0. Exit");
					System.out.println("Enter your choice: ");
					ch = sc.nextInt();
					switch(ch) {
					case 1:
						System.out.println("Registration done successfully");
					break;
					case 2:
						System.out.println("Enter you usename and password");
						String username = sc.next();
						String password = sc.next();
						if(username.equals(password)) {
							do {
								System.out.println("1. Profile");
								System.out.println("2. Service");
								System.out.println("3. Appointment");
								System.out.println("0. Exit");
								System.out.println("Enter you choice: ");
								ch = sc.nextInt();
								switch(ch) {
								case 1:
									System.out.println("PROFILE");
									do {
										System.out.println("1. View profile");
										System.out.println("2. Update profile");
										System.out.println("3. Delete profile");
										System.out.println("0. Exit");
										System.out.println("Enter your choice: ");
										ch = sc.nextInt();
										switch(ch) {
										case 1:
											System.out.println("profile viewed successfully");
										break;
										case 2:
											System.out.println("profile updated successfully");
										break;
										case 3:
											System.out.println("profile deleted successfully");
										break;
										case 0:
											System.out.println("Thank you,");
										break;
										default:
											System.out.println("Invalid Choice");
										}
									}while(ch != 0);
								break;
								case 2:
									System.out.println("Servie Viewed Successfully");
								break;
								case 3:
									System.out.println("APPOINTMENT");
									do {
										System.out.println("1. Add appointment");
										System.out.println("2. View appointment");
										System.out.println("3. Update appointment");
										System.out.println("4. Delete appointment");
										System.out.println("0. Exit");
										System.out.println("Enter your choice: ");
										ch = sc.nextInt();
										switch(ch) {
										case 1:
											System.out.println("appointment added successfully");
										break;
										case 2:
											System.out.println("profile viewed successfully");
										break;
										case 3:
											System.out.println("profile updated successfully");
										break;
										case 4:
											System.out.println("profile deleted successfully");
										break;
										case 0:
											System.out.println("Thank you,");
										break;
										default:
											System.out.println("Invalid Choice");
										}
									}while(ch != 0);
								break;
								case 0:
									System.out.println("Thank you,");
								break;
								default:
									System.out.println("Invalid Choice");
								}
							}while(ch != 0);
						}
						else {
							break;
						}
					break;
					case 0:
						System.out.println("Thank you,");	
					break;
					default:
						System.out.println("Invalid Choice");
					}
				}while(ch != 0);
				ch = 1;
			break;
			case 2: // admin
				do {
					System.out.println("1. Login");
					System.out.println("0. Exit");
					ch = sc.nextInt();
					switch(ch) {
						
					}
				}while(ch != 0);
			break;
			case 0: // exit
				System.out.println("Thank you,");
			break;
			default: // invalid choice
				System.out.println("Invalid Choice");
			break;
			}
		}while(ch != 0);
	}
}
