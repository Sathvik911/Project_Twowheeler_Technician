package com.Test;

import java.util.Scanner;
import com.Test.CustomerTest;
import com.Pojo.Customer;
public class Driver 
{
	static Scanner sc = new Scanner(System.in);
	static CustomerTest obj = new CustomerTest();
	static TechnicianTest tt = new TechnicianTest();
	static ServiceTest s = new ServiceTest();
	static AppointmentTest at = new AppointmentTest();
	public static void customerProfileMenu() {
		Customer lc = obj.getCustomerLoginObject();
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\t"+lc.getCusername()+" Profile DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. View profile");
		System.out.println("2. Update profile");
		System.out.println("3. Delete pofile");
		System.out.println("0. Exit");
		System.out.println("Enter your choice: ");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			obj.getCustomerByUsername();
			customerProfileMenu();
		break;
		case 2:
			obj.updateCustomerByUsername();
			customerProfileMenu();
		break;
		case 3:
			obj.deleteCustomerByUsername();
			runMenu();
		break;
		case 0:
			System.out.println("Thank you.");
			customerHomeMenu();
		break;
		default:
			System.out.println("Invalid Choice, please try again");
			customerProfileMenu();
		}
	}
	public static void customerServiceMenu() {
		Customer lc = obj.getCustomerLoginObject();
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\t"+lc.getCusername()+" Service DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. View service");
		System.out.println("0. Exit");
		System.out.println("Enter your choice: ");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			s.showAllService();
			customerServiceMenu();
		break;
		case 0:
			System.out.println("Thank you.");
			customerHomeMenu();
		break;
		default:
			System.out.println("Invalid Choice, please try again");
			customerServiceMenu();
		}
	}
	public static void customerAppointmentMenu() {
		Customer lc = obj.getCustomerLoginObject();
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\t"+lc.getCusername()+" Appointment DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. Make appointment");
		System.out.println("2. View appointment");
		System.out.println("3. Update appointment service");
		System.out.println("4. Update appointment date");
		System.out.println("5. Delete appointment");
		System.out.println("0. Exit");
		System.out.println("Enter your choice: ");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			//make appointment
			at.makeAppointment(lc);
			customerAppointmentMenu();
		break;
		case 2:
			//view appointment
			at.getAppointmentByCustomerID(lc);
			customerAppointmentMenu();
		break;
		case 3:
			//update appointment by service
			at.getAppointmentByCustomerID(lc);
			at.updateAppointmentService(lc);
			customerAppointmentMenu();
		break;
		case 4:
			//update appointment by date
			at.getAppointmentByCustomerID(lc);
			at.updateAppointmentDate(lc);
			customerAppointmentMenu();
		break;
		case 5:
			//delete appointment
			at.getAppointmentByCustomerID(lc);
			at.deleteAppointment();
			customerAppointmentMenu();
		break;
		case 0:
			System.out.println("Thank you.");
			customerHomeMenu();
		break;
		default:
			System.out.println("Invalid Choice, please try again");
			customerAppointmentMenu();
		}
	}
	public static void customerHomeMenu() {
		Customer lc = obj.getCustomerLoginObject();
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\t"+lc.getCusername()+" Home DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. Profile");
		System.out.println("2. Service");
		System.out.println("3. Appointment");
		System.out.println("0. Logout");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			customerProfileMenu();
		break;
		case 2:
			customerServiceMenu();
		break;
		case 3:
			customerAppointmentMenu();
		break;
		case 0:
			System.out.println("Thank you");
			customerMenu();
		break;
		default:
			System.out.println("Invalid choice");
			customerHomeMenu();
		}
	}
	public static void customerMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tCustomer DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. Register");
		System.out.println("2. Login");
		System.out.println("0. Exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			obj.registerCustomer();
			runMenu();
		break;
		case 2:
			if(obj.loginCustomer()) {
				System.out.println("Login Done Successfully");
				customerHomeMenu();
			}
			else {
				System.out.println("Invalid Login Credentials!");
				customerMenu();
			}
		break;
		case 0:
			System.out.println("Thank you.");
			runMenu();
		break;
		default:
			System.out.println("Invalid Choice");
			customerMenu();
		}
	}
	public static void runMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tHome DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. Customer");
		System.out.println("2. Admin");
		System.out.println("3. Technician");
		System.out.println("0. Exit");
		System.out.println("Enter your choice: ");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			customerMenu();
		break;
		case 2:
			adminMenu();
		break;
		case 3:
			technicianMenu();
		break;
		case 0:
			System.out.println("Thank you");
		break;
		default:
			System.out.println("Invalid Choice");
			runMenu();
		}
	}
	
	public static void technicianMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tTechnician DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. Technician Login");
		System.out.println("0. Exit");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			if(tt.loginTechnician()) {
				System.out.println("Login Done Successfully");
				technicianHomeMenu();
			}
			else {
				System.out.println("Invalid Login Credentials!");
				technicianMenu();
			}
			technicianHomeMenu();
		break;
		case 0:
			System.out.println("Thank you,");
			runMenu();
		break;
		default:
			System.out.println("Invalid Choice");
			technicianMenu();
		}
	}
	
	public static void technicianHomeMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tTechnician DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. view technicain details");
		System.out.println("2. update technicain details");
		System.out.println("3. show technician appointments");
		System.out.println("0. Exit");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			tt.getTechnicianById();
			technicianHomeMenu();
		break;
		case 2:
			tt.updateTechnician();
			technicianHomeMenu();
		break;
		case 3:
			System.out.println("show all appointments");
			technicianHomeMenu();
		break;
		case 0:
			System.out.println("Thank you,");
			technicianMenu();
		break;
		default:
			System.out.println("Invalid Choice");
			technicianHomeMenu();
		}
	}
	
	public static void main(String args[]) {
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\n\tWelcome to Online Two Wheeler Technician Appointment System");
		System.out.println("--------------------------------------------------------------------------");
		runMenu();
		System.out.println("program completed!, You may now close the concole");
	}
	
	public static void adminCustomerMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tAdmin Customer DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. View Customers");
		System.out.println("2. Delete Customer");
		System.out.println("0. Exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Customer viwed successfully");
			adminCustomerMenu();
		break;
		case 2:
			System.out.println("Customer deleted successfully");
			adminCustomerMenu();
		break;
		case 0:
			System.out.println("Thank you");
			loginAdminMenu();
		break;
		default:
			System.out.println("Invalid Choice");
			adminCustomerMenu();
		}
	}
	
	public static void adminTechnicianMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tAdmin Technician DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. View Technicians");
		System.out.println("2. Update Technician");
		System.out.println("3. Delete Technician");
		System.out.println("0. Exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Technician viwed successfully");
			adminTechnicianMenu();
		break;
		case 2:
			System.out.println("Technician updated successfully");
			adminTechnicianMenu();
		break;
		case 3:
			System.out.println("Technician deleted successfully");
			adminTechnicianMenu();
		break;
		case 0:
			System.out.println("Thank you");
			loginAdminMenu();
		break;
		default:
			System.out.println("Invalid Choice");
			adminTechnicianMenu();
		}
	}
	
	public static void adminServiceMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tAdmin Service DashBoard");
		System.out.println("---------------s-----------------------------------------------------------");
		System.out.println("1. View Services");
		System.out.println("2. Update Service");
		System.out.println("3. Delete Service");
		System.out.println("0. Exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Service viwed successfully");
			adminServiceMenu();
		break;
		case 2:
			System.out.println("Service updated successfully");
			adminServiceMenu();
		break;
		case 3:
			System.out.println("Service deleted successfully");
			adminServiceMenu();
		break;
		case 0:
			System.out.println("Thank you");
			loginAdminMenu();
		break;
		default:
			System.out.println("Invalid Choice");
			adminServiceMenu();
		}
	}
	
	public static void adminAppointmentMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tAdmin Appointment DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. View Appointments");
		System.out.println("2. Update Appointments");
		System.out.println("3. Delete Appointments");
		System.out.println("0. Exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Appointment viwed successfully");
			adminAppointmentMenu();
		break;
		case 2:
			System.out.println("Appointment updated successfully");
			adminAppointmentMenu();
		break;
		case 3:
			System.out.println("Appointment deleted successfully");
			adminAppointmentMenu();
		break;
		case 0:
			System.out.println("Thank you");
			loginAdminMenu();
		break;
		default:
			System.out.println("Invalid Choice");
			adminAppointmentMenu();
		}
	}
	
	public static void loginAdminMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tAdmin Login DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. Appointment");
		System.out.println("2. Technician");
		System.out.println("3. Service");
		System.out.println("4. Customer");
		System.out.println("0. Exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			adminAppointmentMenu();
		break;
		case 2:
			adminTechnicianMenu();
		break;
		case 3:
			adminServiceMenu();
		break;
		case 4:
			adminCustomerMenu();
		break;
		case 0:
			System.out.println("Thank you");
			adminMenu();
		break;
		default:
			System.out.println("Invalid choice");
			loginAdminMenu();
		}
	}
	public static void adminMenu() {
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("\t\t\tAdmin DashBoard");
		System.out.println("--------------------------------------------------------------------------");
		System.out.println("1. Login");
		System.out.println("0. Exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Enter username");
			String username = sc.next();
			if(username.equals("admin")) {
				System.out.println("Admin Login Done Successfully");
				loginAdminMenu();
			}
			else {
				System.out.println("Invalid username or password");
				adminMenu();
			}
		break;
		case 0:
			System.out.println("Thank you");
			runMenu();
		break;
		default:
			System.out.println("Invalid Choice");
			runMenu();
		}
	}
}
