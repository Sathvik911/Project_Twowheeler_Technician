package com.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import com.DaoIMPL.TechnicianDaoIMPL;
import com.Pojo.Technician;

public class TechnicianTest 
{
	TechnicianDaoIMPL cd = new TechnicianDaoIMPL();
	boolean result;
	List<Technician> li = new ArrayList<Technician>();
	Iterator it;
	Technician tt;
	Technician obj;
	int tid;
	String tusername, tpassword, taddress, tcontact;
	Scanner sc = new Scanner(System.in);
	
	public void addTechnician() {
		System.out.println("Enter technician username ");
		tusername = sc.next();
		System.out.println("Enter technician password ");
		tpassword = sc.next();
		System.out.println("Enter technician address ");
		taddress = sc.next();
		System.out.println("Enter technician contact ");
		tcontact = sc.next();
		result = cd.AddTechnician(new Technician(tusername,tpassword,taddress,tcontact,0));
		if(result)
				System.out.println("Technician Added successfully. ");
			else
				System.out.println("Technician Not Added successfully. ");
	}	
				
	public boolean loginTechnician() {
		System.out.println("Enter your name ");
		tusername = sc.next();
		System.out.println("Enter your password ");
		tpassword = sc.next();
		li = cd.getTechnicianByUsernamePassword(tusername,tpassword);
		if(!li.isEmpty()) {
			tt = li.get(0);
			return true;
		}
		return false;
	}
	
	public void updateTechnician() {
		System.out.println("Enter new technician username ");
		tusername = sc.next();
		System.out.println("Enter new technician password ");
		tpassword = sc.next();
		System.out.println("Enter new technician address ");
		taddress = sc.next();
		System.out.println("Enter new technician contact ");
		tcontact = sc.next();
		Technician t = new Technician(tusername,tpassword,taddress,tcontact,tt.getTisAssigned());
		t.setTid(tt.getTid());
		result = cd.UpdateTechnician(t);
		if(result)
			System.out.println("Technician Updated Successfully. ");
		else
			System.out.println("Technician Not Updated Successfully. ");
	}
	
	/*
	public void updateCustomerByUsername() {
		System.out.println("Enter new cpassword ");
		cpassword = sc.next();
		System.out.println("Enter new ccontact ");
		ccontact = sc.next();
		System.out.println("Enter new caddress ");
		caddress = sc.next();
		Customer c = new Customer(cusername,cpassword,ccontact,caddress);
		c.setCid(cid);
		System.out.println(cusername);
		result = cd.UpdateCustomerByUsername(c);
		if(result)
			System.out.println("Customer updated successfully. ");
		else
			System.out.println("Customer not updated successfully. ");
	}*/
			
	public void deleteTechnician()
	{
		System.out.println("Enter technician id you want to delete ");
		tid = sc.nextInt();
		result = cd.DeleteTechnician(tid);
		if(result)
			System.out.println("Technician Deleted Successfully. ");
		else
			System.out.println("Technician Not Deleted Successfully. ");
	}
	
	/*
	public void deleteCustomerByUsername()
	{
		result = cd.DeleteCustomerByUsername(cusername);
		if(result)
			System.out.println("Customer Deleted Successfully. ");
		else
			System.out.println("Customer Not Deleted Successfully. ");
	}*/
				
	public void getTechnicianById()
	{
		li = cd.getTechnicianById(tt.getTid());
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}	
	
	/*
	public void getTechnicianByUsername()
	{
		li = cd.getCustomerByUsername(tt.getTusername());
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}*/
		
	/*
	public void updateCustomerU(String cusername)
	{
		System.out.println("Enter customer username ");
		cusername = sc.next();
		li = cd.getCustomerByUsername(cusername);
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}*/
							
	public void showAllTechnicians()
	{
		li = cd.getAllTechnicians();
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}	
}
