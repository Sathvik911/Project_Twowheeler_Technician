package com.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import com.DaoIMPL.ServiceDaoIMPL;
import com.Pojo.Service;

public class ServiceTest 
{
	ServiceDaoIMPL cd = new ServiceDaoIMPL();
	boolean result;
	List<Service> li = new ArrayList<Service>();
	Iterator it;
	int sid;
	String sname, scharge;
	Scanner sc = new Scanner(System.in);
	
	public void addService() {
		System.out.println("Enter service name ");
		sname = sc.next();
		System.out.println("Enter service charge ");
		scharge = sc.next();
		result = cd.AddService(new Service(sname,scharge));
		if(result)
				System.out.println("Service Added successfully. ");
			else
				System.out.println("Service Not Added successfully. ");
	}	
				
	public void updateService() {
		System.out.println("Enter service you want to update ");
		sname = sc.nextLine();
		System.out.println("Enter new service charge ");
		scharge = sc.next();
		Service c = new Service(sname,scharge);
		c.setSid(sid);
		result = cd.UpdateServiceCharge(c);
		if(result)
			System.out.println("Service updated successfully. ");
		else
			System.out.println("Service not updated successfully. ");
	}
	
			
	public void deleteService()
	{
		System.out.println("Enter service name you want to delete ");
		sname = sc.nextLine();
		result = cd.DeleteService(sname);
		if(result)
			System.out.println("Service Deleted Successfully. ");
		else
			System.out.println("Service Not Deleted Successfully. ");
	}
	
							
	public void showAllService()
	{
		li = cd.getAllService();
		it = li.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}	
}
