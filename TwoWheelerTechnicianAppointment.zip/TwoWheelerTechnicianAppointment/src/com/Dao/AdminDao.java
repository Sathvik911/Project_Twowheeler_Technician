package com.Dao;

import java.util.List;

import com.Pojo.Admin;

public interface AdminDao {
	public boolean AddAdmin(Admin a);
	public boolean UpdateAdmin(Admin c);
	public boolean DeleteAdmin(int id);
	public List<Admin> getAdminById(int id);
	public List<Admin> getAdminByUsername(String username);
	public List<Admin> getAllAdmins();
}
