package com.DaoIMPL;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.DBUtility.DBConnection;
import com.Pojo.Service;

public class ServiceDaoIMPL 
{
	java.sql.Connection con = DBConnection.connection();
	PreparedStatement stmt;
	int row = 0;
	ResultSet rs;
	public boolean AddService(Service s) 
	{
		try 
		{
			stmt = con.prepareStatement("INSERT INTO Service(sname,scharge) values(?,?)");
			stmt.setString(1, s.getSname());
			stmt.setString(2, s.getScharge());
			row = stmt.executeUpdate();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		if(row>0)
			return true;
		return false;
	}

	
	public boolean UpdateServiceCharge(Service s) 
	{
		try 
		{
			stmt = con.prepareStatement("UPDATE Service SET scharge=? WHERE sname=?");
			stmt.setString(1, s.getScharge());
			stmt.setString(2, s.getSname());
			row = stmt.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		if(row>0)
			return true;
		return false;
	}


	public boolean DeleteService(String sname) 
	{
		try 
		{
			stmt = con.prepareStatement("DELETE FROM Service WHERE sname=?");
			stmt.setString(1, sname);
			row = stmt.executeUpdate();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		if(row>0)
			return true;
		return false;
	}

	
	public List<Service> getAllService() 
	{
		List<Service> li = new ArrayList<Service>();
		Service s;
		try 
		{
			stmt = con.prepareStatement("SELECT * FROM Service");
			rs = stmt.executeQuery();
			while(rs.next())
			{
			s = new Service(rs.getString("sname"),rs.getString("scharge"));
			s.setSid(rs.getInt("sid"));
			li.add(s);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return li;
	}
}
