package com.DaoIMPL;

import java.util.List;

import com.Dao.AdminDao;
import com.Pojo.Admin;

public class AdminDaoIMPL implements AdminDao {

	@Override
	public boolean AddAdmin(Admin a) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean UpdateAdmin(Admin c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteAdmin(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Admin> getAdminById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> getAdminByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> getAllAdmins() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
